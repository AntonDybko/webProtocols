window.addEventListener("load", function (event) {
 console.log("Ten napis pojawi się w konsoli interfejsu programistycznego (skrót F12 w przeglądarce)");
});
